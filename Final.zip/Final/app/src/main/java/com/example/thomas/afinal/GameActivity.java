package com.example.thomas.afinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.view.View;
import android.widget.TextView;




public class GameActivity extends AppCompatActivity {

    TextView score;

    ImageButton light1;
    ImageButton light2;
    ImageButton light3;
    ImageButton light4;
    ImageButton light5;

    ImageButton light6;
    ImageButton light7;
    ImageButton light8;
    ImageButton light9;
    ImageButton light10;

    ImageButton light11;
    ImageButton light12;
    ImageButton light13;
    ImageButton light14;
    ImageButton light15;

    ImageButton light16;
    ImageButton light17;
    ImageButton light18;
    ImageButton light19;
    ImageButton light20;

    ImageButton light21;
    ImageButton light22;
    ImageButton light23;
    ImageButton light24;
    ImageButton light25;



    //setting booleans to test
    Boolean l1 = true;
    Boolean l2 = true;
    Boolean l3 = true;
    Boolean l4 = true;
    Boolean l5 = true;

    Boolean l6 = true;
    Boolean l7 = true;
    Boolean l8 = true;
    Boolean l9 = true;
    Boolean l10 = true;

    Boolean l11 = true;
    Boolean l12 = true;
    Boolean l13 = true;
    Boolean l14 = true;
    Boolean l15 = true;

    Boolean l16 = true;
    Boolean l17 = true;
    Boolean l18 = true;
    Boolean l19 = true;
    Boolean l20 = true;

    Boolean l21 = true;
    Boolean l22 = true;
    Boolean l23 = true;
    Boolean l24 = true;
    Boolean l25 = true;

    //attempts to solve
    int taps = 0;


    String times = Integer.toString(taps);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        light1 = (ImageButton) findViewById(R.id.idLight1);
        light2 = (ImageButton) findViewById(R.id.idLight2);
        light3 = (ImageButton) findViewById(R.id.idLight3);
        light4 = (ImageButton) findViewById(R.id.idLight4);
        light5 = (ImageButton) findViewById(R.id.idLight5);

        light6 = (ImageButton) findViewById(R.id.idLight6);
        light7 = (ImageButton) findViewById(R.id.idLight7);
        light8 = (ImageButton) findViewById(R.id.idLight8);
        light9 = (ImageButton) findViewById(R.id.idLight9);
        light10 = (ImageButton) findViewById(R.id.idLight10);

        light11 = (ImageButton) findViewById(R.id.idLight11);
        light12 = (ImageButton) findViewById(R.id.idLight12);
        light13 = (ImageButton) findViewById(R.id.idLight13);
        light14 = (ImageButton) findViewById(R.id.idLight14);
        light15 = (ImageButton) findViewById(R.id.idLight15);

        light16 = (ImageButton) findViewById(R.id.idLight16);
        light17 = (ImageButton) findViewById(R.id.idLight17);
        light18 = (ImageButton) findViewById(R.id.idLight18);
        light19 = (ImageButton) findViewById(R.id.idLight19);
        light20 = (ImageButton) findViewById(R.id.idLight20);

        light21 = (ImageButton) findViewById(R.id.idLight21);
        light22 = (ImageButton) findViewById(R.id.idLight22);
        light23 = (ImageButton) findViewById(R.id.idLight23);
        light24 = (ImageButton) findViewById(R.id.idLight24);
        light25 = (ImageButton) findViewById(R.id.idLight25);


        score = (TextView) findViewById(R.id.idScore);



// lights 1-5

        //-------------------------Button one-------------------------------------//
        light1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button

                //main button
                if(l1){

                    l1 = false;
                    (light1).setImageResource(R.drawable.off);
                }else if (!l1){

                    l1 = true;
                    (light1).setImageResource(R.drawable.on);
                }
                //Right Button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off);
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on);
                }
                //Bottom Button
                if(l6){

                    l6 = false;
                    (light6).setImageResource(R.drawable.off);
                }else if(!l6){
                    l6 = true;
                    (light6).setImageResource(R.drawable.on);
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); //leave this line to assign a specific text
            }

        });

        //-------------------------Button two-------------------------------------//
        light2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button
                if(l1){

                    l1 = false;
                    (light1).setImageResource(R.drawable.off);
                }else if (!l1){

                    l1 = true;
                    (light1).setImageResource(R.drawable.on);
                }
                //main button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off);
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on);
                }
                //Right Button
                if(l3){

                    l3 = false;
                    (light3).setImageResource(R.drawable.off);
                }else if (!l3){

                    l3 = true;
                    (light3).setImageResource(R.drawable.on);
                }
                //Bottom Button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off);
                }else if(!l7){
                    l7 = true;
                    (light7).setImageResource(R.drawable.on);
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); //leave this line to assign a specific text
            }

        });

    }



}

