package com.example.thomas.afinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.view.View;
import android.widget.TextView;




public class GameActivity extends AppCompatActivity {

    TextView score;
    TextView insults;

    String in1 = "You win!";
    String in2 = "So Close...";
    String in3 = "Wow, im marginally impressed...";
    String in4 = "I expect better!";
    String in5 = "And your Off! or On?";
    String in6 = "I've seen better...";
    String in7 = "Lower the score the better!";

    ImageButton light1;
    ImageButton light2;
    ImageButton light3;
    ImageButton light4;
    ImageButton light5;

    ImageButton light6;
    ImageButton light7;
    ImageButton light8;
    ImageButton light9;
    ImageButton light10;

    ImageButton light11;
    ImageButton light12;
    ImageButton light13;
    ImageButton light14;
    ImageButton light15;

    ImageButton light16;
    ImageButton light17;
    ImageButton light18;
    ImageButton light19;
    ImageButton light20;

    ImageButton light21;
    ImageButton light22;
    ImageButton light23;
    ImageButton light24;
    ImageButton light25;

    Button reset;


    //setting booleans to test
    Boolean l1 = true;
    Boolean l2 = true;
    Boolean l3 = true;
    Boolean l4 = true;
    Boolean l5 = true;

    Boolean l6 = true;
    Boolean l7 = true;
    Boolean l8 = true;
    Boolean l9 = true;
    Boolean l10 = true;

    Boolean l11 = true;
    Boolean l12 = true;
    Boolean l13 = true;
    Boolean l14 = true;
    Boolean l15 = true;

    Boolean l16 = true;
    Boolean l17 = true;
    Boolean l18 = true;
    Boolean l19 = true;
    Boolean l20 = true;

    Boolean l21 = true;
    Boolean l22 = true;
    Boolean l23 = true;
    Boolean l24 = true;
    Boolean l25 = true;

    //attempts to solve
    int taps = 0;

    //number of lights
    int numLights = 24;

    String times = Integer.toString(taps);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        light1 = (ImageButton) findViewById(R.id.idLight1);
        light2 = (ImageButton) findViewById(R.id.idLight2);
        light3 = (ImageButton) findViewById(R.id.idLight3);
        light4 = (ImageButton) findViewById(R.id.idLight4);
        light5 = (ImageButton) findViewById(R.id.idLight5);

        light6 = (ImageButton) findViewById(R.id.idLight6);
        light7 = (ImageButton) findViewById(R.id.idLight7);
        light8 = (ImageButton) findViewById(R.id.idLight8);
        light9 = (ImageButton) findViewById(R.id.idLight9);
        light10 = (ImageButton) findViewById(R.id.idLight10);

        light11 = (ImageButton) findViewById(R.id.idLight11);
        light12 = (ImageButton) findViewById(R.id.idLight12);
        light13 = (ImageButton) findViewById(R.id.idLight13);
        light14 = (ImageButton) findViewById(R.id.idLight14);
        light15 = (ImageButton) findViewById(R.id.idLight15);

        light16 = (ImageButton) findViewById(R.id.idLight16);
        light17 = (ImageButton) findViewById(R.id.idLight17);
        light18 = (ImageButton) findViewById(R.id.idLight18);
        light19 = (ImageButton) findViewById(R.id.idLight19);
        light20 = (ImageButton) findViewById(R.id.idLight20);

        light21 = (ImageButton) findViewById(R.id.idLight21);
        light22 = (ImageButton) findViewById(R.id.idLight22);
        light23 = (ImageButton) findViewById(R.id.idLight23);
        light24 = (ImageButton) findViewById(R.id.idLight24);
        light25 = (ImageButton) findViewById(R.id.idLight25);

        reset = (Button) findViewById(R.id.idReset);

        score = (TextView) findViewById(R.id.idScore);
        insults = (TextView) findViewById(R.id.idInsult);

// Buttons

        //-------------------------Button reset-------------------------------------//
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                l1 = true;
                l2 = true;
                l3 = true;
                l4 = true;
                l5 = true;

                l6 = true;
                l7 = true;
                l8 = true;
                l9 = true;
                l10 = true;

                l11 = true;
                l12 = true;
                l13 = true;
                l14 = true;
                l15 = true;

                l16 = true;
                l17 = true;
                l18 = true;
                l19 = true;
                l20 = true;

                l21 = true;
                l22 = true;
                l23 = true;
                l24 = true;
                l25 = true;

                (light1).setImageResource(R.drawable.on);
                (light2).setImageResource(R.drawable.on);
                (light3).setImageResource(R.drawable.on);
                (light4).setImageResource(R.drawable.on);
                (light5).setImageResource(R.drawable.on);

                (light6).setImageResource(R.drawable.on);
                (light7).setImageResource(R.drawable.on);
                (light8).setImageResource(R.drawable.on);
                (light9).setImageResource(R.drawable.on);
                (light10).setImageResource(R.drawable.on);

                (light11).setImageResource(R.drawable.on);
                (light12).setImageResource(R.drawable.on);
                (light13).setImageResource(R.drawable.on);
                (light14).setImageResource(R.drawable.on);
                (light15).setImageResource(R.drawable.on);

                (light16).setImageResource(R.drawable.on);
                (light17).setImageResource(R.drawable.on);
                (light18).setImageResource(R.drawable.on);
                (light19).setImageResource(R.drawable.on);
                (light20).setImageResource(R.drawable.on);

                (light21).setImageResource(R.drawable.on);
                (light22).setImageResource(R.drawable.on);
                (light23).setImageResource(R.drawable.on);
                (light24).setImageResource(R.drawable.on);
                (light25).setImageResource(R.drawable.on);


                numLights = 24;

                taps = 0;
                times = Integer.toString(taps);
                score.setText(times);
                insults.setText(in7);
            }

        });




        //-------------------------Button one-------------------------------------//
        light1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button

                //main button
                if(l1){

                    l1 = false;
                    (light1).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l1){

                    l1 = true;
                    (light1).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l6){

                    l6 = false;
                    (light6).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l6){
                    l6 = true;
                    (light6).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text

            }

        });

        //-------------------------Button two-------------------------------------//
        light2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button
                if(l1){

                    l1 = false;
                    (light1).setImageResource(R.drawable.off); numLights -= 1; numLights -= 1;
                }else if (!l1){

                    l1 = true;
                    (light1).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l3){

                    l3 = false;
                    (light3).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l3){

                    l3 = true;
                    (light3).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l7){
                    l7 = true;
                    (light7).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text

            }

        });

        //-------------------------Button three-------------------------------------//
        light3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l3){

                    l3 = false;
                    (light3).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l3){

                    l3 = true;
                    (light3).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l4){

                    l4 = false;
                    (light4).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l4){

                    l4 = true;
                    (light4).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l8){

                    l8 = false;
                    (light8).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l8){
                    l8 = true;
                    (light8).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
                
            }

        });

        //-------------------------Button four-------------------------------------//
        light4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button
                if(l3){

                    l3 = false;
                    (light3).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l3){

                    l3 = true;
                    (light3).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l4){

                    l4 = false;
                    (light4).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l4){

                    l4 = true;
                    (light4).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l5){

                    l5 = false;
                    (light5).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l5){

                    l5 = true;
                    (light5).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l9){

                    l9 = false;
                    (light9).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l9){
                    l9 = true;
                    (light9).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button five-------------------------------------//
        light5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button

                //Left Button
                if(l4){

                    l4 = false;
                    (light4).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l4){

                    l4 = true;
                    (light4).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l5){

                    l5 = false;
                    (light5).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l5){

                    l5 = true;
                    (light5).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                //Bottom Button
                if(l10){

                    l10 = false;
                    (light10).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l10){
                    l10 = true;
                    (light10).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button six-------------------------------------//
        light6.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l1){

                    l1 = false;
                    (light1).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l1){

                    l1 = true;
                    (light1).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button

                //main button
                if(l6){

                    l6 = false;
                    (light6).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l6){

                    l6 = true;
                    (light6).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l7){

                    l7 = true;
                    (light7).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l11){

                    l11 = false;
                    (light11).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l11){
                    l11 = true;
                    (light11).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button seven-------------------------------------//
        light7.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l2){

                    l2 = false;
                    (light2).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l2){

                    l2 = true;
                    (light2).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l6){

                    l6 = false;
                    (light6).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l6){

                    l6 = true;
                    (light6).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l7){

                    l7 = true;
                    (light7).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l8){

                    l8 = false;
                    (light8).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l8){

                    l8 = true;
                    (light8).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l12){

                    l12 = false;
                    (light12).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l12){
                    l12 = true;
                    (light12).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button eight-------------------------------------//
        light8.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l3){

                    l3 = false;
                    (light3).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l3){

                    l3 = true;
                    (light3).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l7){

                    l7 = true;
                    (light7).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l8){

                    l8 = false;
                    (light8).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l8){

                    l8 = true;
                    (light8).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l9){

                    l9 = false;
                    (light9).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l9){

                    l9 = true;
                    (light9).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l13){

                    l13 = false;
                    (light13).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l13){
                    l13 = true;
                    (light13).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button nine-------------------------------------//
        light9.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l4){

                    l4 = false;
                    (light4).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l4){

                    l4 = true;
                    (light4).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l8){

                    l8 = false;
                    (light8).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l8){

                    l8 = true;
                    (light8).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l9){

                    l9 = false;
                    (light9).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l9){

                    l9 = true;
                    (light9).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l10){

                    l10 = false;
                    (light10).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l10){

                    l10 = true;
                    (light10).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l14){
                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button ten-------------------------------------//
        light10.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l5){

                    l5 = false;
                    (light5).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l5){

                    l5 = true;
                    (light5).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l9){

                    l9 = false;
                    (light9).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l9){

                    l9 = true;
                    (light9).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l10){

                    l10 = false;
                    (light10).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l10){

                    l10 = true;
                    (light10).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button


                //Bottom Button
                if(l15){

                    l15 = false;
                    (light15).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l15){
                    l15 = true;
                    (light15).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button eleven-------------------------------------//
        light11.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l6){

                    l6 = false;
                    (light6).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l6){

                    l6 = true;
                    (light6).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button

                //main button
                if(l11){

                    l11 = false;
                    (light11).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l11){

                    l11 = true;
                    (light11).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l12){

                    l12 = false;
                    (light12).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l12){

                    l12 = true;
                    (light12).setImageResource(R.drawable.on); numLights += 1;
                }

                //Bottom Button
                if(l16){

                    l16 = false;
                    (light16).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l16){
                    l16 = true;
                    (light16).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twelve-------------------------------------//
        light12.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l7){

                    l7 = false;
                    (light7).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l7){

                    l7 = true;
                    (light7).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l11){

                    l11 = false;
                    (light11).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l11){

                    l11 = true;
                    (light11).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l12){

                    l12 = false;
                    (light12).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l12){

                    l12 = true;
                    (light12).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l13){

                    l13 = false;
                    (light13).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l13){

                    l13 = true;
                    (light13).setImageResource(R.drawable.on); numLights += 1;
                }

                //Bottom Button
                if(l17){

                    l17 = false;
                    (light17).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l17){
                    l17 = true;
                    (light17).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button thirteen-------------------------------------//
        light13.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l8){

                    l8 = false;
                    (light8).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l8){

                    l8 = true;
                    (light8).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l12){

                    l12 = false;
                    (light12).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l12){

                    l12 = true;
                    (light12).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l13){

                    l13 = false;
                    (light13).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l13){

                    l13 = true;
                    (light13).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l14){

                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }

                //Bottom Button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l18){
                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button fourteen-------------------------------------//
        light14.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l9){

                    l9 = false;
                    (light9).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l9){

                    l9 = true;
                    (light9).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l13){

                    l13 = false;
                    (light13).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l13){

                    l13 = true;
                    (light13).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l14){

                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l15){

                    l15 = false;
                    (light15).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l15){

                    l15 = true;
                    (light15).setImageResource(R.drawable.on); numLights += 1;
                }

                //Bottom Button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l19){
                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button fifteen-------------------------------------//
        light15.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l10){

                    l10 = false;
                    (light10).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l10){

                    l10 = true;
                    (light10).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l14){

                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l15){

                    l15 = false;
                    (light15).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l15){

                    l15 = true;
                    (light15).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                //Bottom Button
                if(l20){

                    l20 = false;
                    (light20).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l20){
                    l20 = true;
                    (light20).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button sixteen-------------------------------------//
        light16.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l11){

                    l11 = false;
                    (light11).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l11){

                    l11 = true;
                    (light11).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button

                //main button
                if(l16){

                    l16 = false;
                    (light16).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l16){

                    l16 = true;
                    (light16).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l17){

                    l17 = false;
                    (light17).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l17){

                    l17 = true;
                    (light17).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l21){

                    l21 = false;
                    (light21).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l21){
                    l21 = true;
                    (light21).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button seventeen-------------------------------------//
        light17.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l12){

                    l12 = false;
                    (light12).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l12){

                    l12 = true;
                    (light12).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l16){

                    l16 = false;
                    (light16).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l16){

                    l16 = true;
                    (light16).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l17){

                    l17 = false;
                    (light17).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l17){

                    l17 = true;
                    (light17).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l18){

                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l22){

                    l22 = false;
                    (light22).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l22){
                    l22 = true;
                    (light22).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button eighteen-------------------------------------//
        light18.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l13){

                    l13 = false;
                    (light13).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l13){

                    l13 = true;
                    (light13).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l17){

                    l17 = false;
                    (light17).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l17){

                    l17 = true;
                    (light17).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l18){

                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l19){

                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l23){

                    l23 = false;
                    (light23).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l23){
                    l23 = true;
                    (light23).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button nineteen-------------------------------------//
        light19.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l14){

                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l18){

                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l19){

                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                if(l20){

                    l20 = false;
                    (light20).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l20){

                    l20 = true;
                    (light20).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l24){

                    l24 = false;
                    (light24).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l24){
                    l24 = true;
                    (light24).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button nineteen-------------------------------------//
        light19.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l14){

                    l14 = false;
                    (light14).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l14){

                    l14 = true;
                    (light14).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l18){

                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l19){

                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                if(l20){

                    l20 = false;
                    (light20).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l20){

                    l20 = true;
                    (light20).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button
                if(l24){

                    l24 = false;
                    (light24).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l24){
                    l24 = true;
                    (light24).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twenty-------------------------------------//
        light20.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l15){

                    l15 = false;
                    (light15).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l15){

                    l15 = true;
                    (light15).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l19){

                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l20){

                    l20 = false;
                    (light20).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l20){

                    l20 = true;
                    (light20).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                //Bottom Button
                if(l25){

                    l25 = false;
                    (light25).setImageResource(R.drawable.off); numLights -= 1;
                }else if(!l25){
                    l25 = true;
                    (light25).setImageResource(R.drawable.on); numLights += 1;
                }
                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twentyone-------------------------------------//
        light21.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l16){

                    l16 = false;
                    (light16).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l16){

                    l16 = true;
                    (light16).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button

                //main button
                if(l21){

                    l21 = false;
                    (light21).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l21){

                    l21 = true;
                    (light21).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l22){

                    l22 = false;
                    (light22).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l22){

                    l22 = true;
                    (light22).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button

                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twentytwo-------------------------------------//
        light22.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l17){

                    l17 = false;
                    (light17).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l17){

                    l17 = true;
                    (light17).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l21){

                    l21 = false;
                    (light21).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l21){

                    l21 = true;
                    (light21).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l22){

                    l22 = false;
                    (light22).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l22){

                    l22 = true;
                    (light22).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l23){

                    l23 = false;
                    (light23).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l23){

                    l23 = true;
                    (light23).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button

                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twentythree-------------------------------------//
        light23.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l18){

                    l18 = false;
                    (light18).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l18){

                    l18 = true;
                    (light18).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l22){

                    l22 = false;
                    (light22).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l22){

                    l22 = true;
                    (light22).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l23){

                    l23 = false;
                    (light23).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l23){

                    l23 = true;
                    (light23).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l24){

                    l24 = false;
                    (light24).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l24){

                    l24 = true;
                    (light24).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button

                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twentyfour-------------------------------------//
        light24.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l19){

                    l19 = false;
                    (light19).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l19){

                    l19 = true;
                    (light19).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l23){

                    l23 = false;
                    (light23).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l23){

                    l23 = true;
                    (light23).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button
                if(l24){

                    l24 = false;
                    (light24).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l24){

                    l24 = true;
                    (light24).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button
                if(l25){

                    l25 = false;
                    (light25).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l25){

                    l25 = true;
                    (light25).setImageResource(R.drawable.on); numLights += 1;
                }
                //Bottom Button

                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });

        //-------------------------Button twentyfive-------------------------------------//
        light25.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Do something in response to button click
                //Top Button
                if(l20){

                    l20 = false;
                    (light20).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l20){

                    l20 = true;
                    (light20).setImageResource(R.drawable.on); numLights += 1;
                }
                //Left Button
                if(l24){

                    l24 = false;
                    (light24).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l24){

                    l24 = true;
                    (light24).setImageResource(R.drawable.on); numLights += 1;
                }
                //main button

                if(l25){

                    l25 = false;
                    (light25).setImageResource(R.drawable.off); numLights -= 1;
                }else if (!l25){

                    l25 = true;
                    (light25).setImageResource(R.drawable.on); numLights += 1;
                }
                //Right Button

                //Bottom Button

                taps += 1;
                times = Integer.toString(taps);
                score.setText(times); if(numLights <= 0){
            insults.setText(in1); //leave this line to assign a specific text
        }else if(numLights <= 5){
            insults.setText(in2); //leave this line to assign a specific text
        }else if(numLights <= 10){
            insults.setText(in3); //leave this line to assign a specific text
        }else if(numLights <= 15){
            insults.setText(in4); //leave this line to assign a specific text
        }else if(numLights <= 20){
            insults.setText(in6); //leave this line to assign a specific text
        }else if(numLights <= 24){
            insults.setText(in5); //leave this line to assign a specific text
        } //leave this line to assign a specific text
            }

        });


    }



}